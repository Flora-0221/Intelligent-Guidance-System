create table favorites
(
    id          int auto_increment
        primary key,
    name        varchar(255)                        not null,
    description text                                null,
    created_at  timestamp default CURRENT_TIMESTAMP null,
    user_id     bigint unsigned                     not null,
    constraint fk_user_id
        foreign key (user_id) references user (id)
);

INSERT INTO igsystem.favorites (id, name, description, created_at, user_id) VALUES (1, 'new Folder', 'this is a test for it', '2024-03-20 20:36:25', 1017);
INSERT INTO igsystem.favorites (id, name, description, created_at, user_id) VALUES (3, 'Biology', 'Some biology questions', '2024-03-20 21:04:35', 1018);
INSERT INTO igsystem.favorites (id, name, description, created_at, user_id) VALUES (4, 'Computer', null, '2024-03-20 21:04:35', 1018);