create table likes
(
    id         bigint unsigned auto_increment
        primary key,
    post_id    bigint unsigned                     null,
    user_id    bigint unsigned                     null,
    created_at timestamp default CURRENT_TIMESTAMP null,
    constraint likes_ibfk_1
        foreign key (post_id) references post (id),
    constraint likes_ibfk_2
        foreign key (user_id) references user (id)
);

create index post_id
    on likes (post_id);

create index user_id
    on likes (user_id);

