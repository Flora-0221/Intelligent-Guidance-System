create table topics
(
    id   bigint unsigned auto_increment
        primary key,
    name varchar(100) not null,
    constraint name
        unique (name)
);

INSERT INTO igsystem.topics (id, name) VALUES (1802314958264881155, 'Art');
INSERT INTO igsystem.topics (id, name) VALUES (1802314958264881154, 'Biology');
INSERT INTO igsystem.topics (id, name) VALUES (1802222581877637122, 'Chinese');
INSERT INTO igsystem.topics (id, name) VALUES (1802314958239715329, 'English');
INSERT INTO igsystem.topics (id, name) VALUES (1802319669432963074, 'Find Job');
INSERT INTO igsystem.topics (id, name) VALUES (1802319669370048515, 'Job Selection');
INSERT INTO igsystem.topics (id, name) VALUES (1802314958264881156, 'Learning skills');
INSERT INTO igsystem.topics (id, name) VALUES (1802316987246858243, 'Make Friends');
INSERT INTO igsystem.topics (id, name) VALUES (1802222581877637121, 'Math');
INSERT INTO igsystem.topics (id, name) VALUES (1802316987246858242, 'School Life');
INSERT INTO igsystem.topics (id, name) VALUES (1802319669370048514, 'School selection');
INSERT INTO igsystem.topics (id, name) VALUES (1802316987246858241, 'Teacher');