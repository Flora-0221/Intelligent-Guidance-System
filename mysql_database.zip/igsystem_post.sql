create table post
(
    id         bigint unsigned auto_increment
        primary key,
    title      varchar(255)                        not null,
    content    text                                not null,
    view_count int       default 0                 null,
    like_count int       default 0                 null,
    author_id  bigint unsigned                     null,
    created_at timestamp default CURRENT_TIMESTAMP null,
    constraint post_ibfk_1
        foreign key (author_id) references user (id)
);

create index author_id
    on post (author_id);

INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802222581852471298, 'How to learn English?', 'Learning English is a journey that opens doors to communication, culture, and opportunities worldwide. To effectively learn English, one should immerse oneself in the language through various methods. First, practice regularly by reading English books, articles, and news to improve vocabulary and grammar. Watching movies, TV shows, and listening to music in English helps in understanding pronunciation and natural speech patterns. Additionally, speaking with native speakers or language exchange partners enhances fluency and confidence.

Using language learning apps and online resources provides interactive exercises for practicing writing and listening skills. Joining English language clubs or taking formal courses at language schools provides structured learning and opportunities for feedback. Finally, don’t be afraid to make mistakes; they are crucial for learning and improving.', 0, 434, 1018, '2024-06-16 14:12:01');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223109839847426, 'How to learn Chinese?', 'Learning Chinese, with its rich cultural heritage and global importance, requires dedication and effective strategies. Start by mastering basic Chinese characters and pronunciation through systematic study. Practice regularly using language apps, flashcards, or handwriting practice to reinforce memory retention.

Immersing oneself in Chinese media such as movies, dramas, and music helps in understanding intonation and context. Finding a language partner or joining conversation groups accelerates speaking and listening skills. Additionally, understanding Chinese culture and history provides context and motivation for learning.', 0, 0, 1018, '2024-06-16 14:14:07');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155714, 'Hw to study well?', 'Studying effectively involves strategic planning and disciplined execution. Begin by organizing study materials and setting specific goals for each study session. Create a conducive study environment with minimal distractions to enhance concentration.

Adopt active learning techniques such as summarizing, self-testing, and teaching others to reinforce understanding. Break study sessions into manageable chunks with regular breaks to maintain focus. Reviewing notes consistently and seeking clarification on challenging topics ensures thorough comprehension.', 0, 0, 1018, '2024-06-16 14:15:04');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155715, 'How to improve your learning speed?', 'Improving one''s learning speed requires dedication, strategy, and a constant pursuit of efficiency. Here are a few tips to enhance your learning abilities.

Firstly, set clear and achievable goals. Knowing what you want to achieve will give you a sense of direction and motivation. Secondly, create a study plan that incorporates active learning techniques like discussions, mind mapping, and practice exercises. Active learning is more effective than passive reading or listening.

Moreover, take regular breaks to avoid burnout. Short breaks can help refresh your mind and improve concentration. Additionally, utilize technology to your advantage. Apps and online tools can make studying more interactive and engaging.

Lastly, stay positive and persevere. Learning is a gradual process, and it''s okay to make mistakes. Embrace your challenges as opportunities for growth. Remember, consistency is key. With these tips and a positive mindset, you can significantly enhance your learning speed and unlock your full potential.', 0, 0, 1018, '2024-06-16 14:26:01');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155716, 'Learning alone or as a team

', 'The choice between learning alone or as part of a team depends on personal preference and learning objectives. Independent learning allows flexibility and personalized pacing, focusing solely on individual strengths and weaknesses. In contrast, collaborative learning fosters teamwork, critical thinking, and diverse perspectives.

Both approaches have their merits; solo learners develop self-discipline and autonomy, while team learners benefit from shared knowledge and social interaction. Ultimately, the effectiveness of each method depends on the learner’s goals, preferences, and the nature of the subject being studied.

', 0, 0, 1018, '2024-06-16 14:26:31');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155726, 'The influence of the family on the child

', 'Family plays a pivotal role in a child''s development, shaping their values, beliefs, and social skills from an early age. Positive family dynamics, characterized by love, support, and open communication, foster emotional resilience and self-confidence in children. Family traditions and rituals provide stability and a sense of identity.

Conversely, negative family influences such as conflict or neglect can impact a child''s emotional well-being and behavior. Parents and caregivers serve as role models, influencing children''s attitudes towards education, relationships, and societal norms. Ultimately, a nurturing family environment promotes a child''s overall growth and well-rounded development.', 0, 0, 1018, '2024-06-16 20:19:06');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155727, 'The impact of school on the child

', 'Schools are instrumental in a child''s intellectual, social, and emotional development. Beyond academic learning, schools provide opportunities for socialization, teamwork, and extracurricular activities that build confidence and interpersonal skills. Qualified teachers facilitate learning through structured curriculum, personalized instruction, and assessments that cater to diverse learning needs.

Schools also play a crucial role in shaping children''s values, attitudes, and civic responsibility through moral education and community involvement. However, the quality of education and school environment significantly influence a child''s educational outcomes and overall well-being. Collaboration between educators, parents, and policymakers is essential to creating supportive learning environments that nurture each child''s potential.', 0, 2, 1018, '2024-06-16 20:27:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155728, 'How to learn effectively

', 'Learning effectively involves adopting strategies that maximize understanding and retention. Begin by setting clear goals and objectives for learning outcomes. Organize study materials systematically and prioritize tasks based on importance and urgency.

Use active learning techniques such as summarizing, self-testing, and teaching others to reinforce understanding. Create a conducive study environment with minimal distractions and adequate resources. Regularly review and revise learned material to consolidate knowledge and identify areas for improvement.

', 0, 0, 1018, '2024-06-16 20:37:49');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155729, 'How to learn happily

', 'Learning happily involves cultivating a positive mindset and enjoying the process of acquiring new knowledge and skills. Find subjects or topics that genuinely interest and motivate you. Set realistic expectations and celebrate small achievements along the way.

Engage in interactive and enjoyable learning activities such as games, simulations, or hands-on projects. Surround yourself with supportive peers, mentors, or teachers who encourage and inspire your learning journey. Take breaks and practice self-care to maintain a healthy balance between learning and relaxation.', 0, 0, 1018, '2024-06-16 21:33:02');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155731, 'How to get along with classmates

', 'Learning happily involves cultivating a positive mindset and enjoying the process of acquiring new knowledge and skills. Find subjects or topics that genuinely interest and motivate you. Set realistic expectations and celebrate small achievements along the way.

Engage in interactive and enjoyable learning activities such as games, simulations, or hands-on projects. Surround yourself with supportive peers, mentors, or teachers who encourage and inspire your learning journey. Take breaks and practice self-care to maintain a healthy balance between learning and relaxation.', 0, 0, 1018, '2024-06-17 12:58:30');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155733, 'Do you feel happy about college life?

', 'Learning happily involves cultivating a positive mindset and enjoying the process of acquiring new knowledge and skills. Find subjects or topics that genuinely interest and motivate you. Set realistic expectations and celebrate small achievements along the way.

Engage in interactive and enjoyable learning activities such as games, simulations, or hands-on projects. Surround yourself with supportive peers, mentors, or teachers who encourage and inspire your learning journey. Take breaks and practice self-care to maintain a healthy balance between learning and relaxation.', 0, 0, 1018, '2024-06-17 20:02:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155734, 'This is po', '# HI
## Hello', 0, 0, 1018, '2024-06-18 12:33:40');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155735, '', '# Hi
## this is a test
+ what 
```
python 
```', 0, 0, 1018, '2024-10-18 19:30:30');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155736, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:32:16');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155737, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:24');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155738, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:24');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155739, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:24');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155740, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:24');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155741, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:24');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155742, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:24');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155743, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:24');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155744, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:24');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155745, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:24');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155746, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155747, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155748, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155749, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155750, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155751, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155752, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155753, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155754, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155755, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155756, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:25');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155757, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:26');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155758, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:26');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155759, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:26');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155760, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:26');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155761, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:26');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155762, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:26');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155763, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:26');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155764, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:26');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155765, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:26');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155766, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:27');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155767, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:27');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155768, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:27');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155769, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:27');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155770, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:27');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155771, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:27');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155772, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:27');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155773, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:35:27');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155774, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:07');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155775, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:07');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155776, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:07');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155777, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:07');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155778, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155779, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155780, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155781, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155782, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155783, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155784, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155785, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155786, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155787, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155788, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155789, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155790, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155791, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155792, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155793, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155794, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155795, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155796, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155797, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155798, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155799, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155800, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155801, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155802, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155803, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155804, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155805, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155806, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155807, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155808, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155809, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:36:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155810, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:04');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155811, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:04');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155812, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:05');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155813, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:05');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155814, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:05');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155815, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:05');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155816, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:05');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155817, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:05');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155818, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:05');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155819, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:06');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155820, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:06');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155821, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:06');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155822, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:06');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155823, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:06');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155824, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:07');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155825, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:07');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155826, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:07');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155827, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:07');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155828, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155829, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155830, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155831, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:08');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155832, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155833, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155834, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155835, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155836, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:09');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155837, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155838, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155839, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155840, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:10');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155841, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155842, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155843, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155844, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155845, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:11');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155846, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:12');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155847, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:12');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155848, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:12');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155849, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:12');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155850, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:12');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155851, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:13');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155852, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:13');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155853, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:13');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155854, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:14');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155855, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:14');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155856, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:14');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155857, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:14');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155858, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:15');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155859, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:15');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155860, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:15');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155861, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:15');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155862, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:15');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155863, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:15');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155864, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:15');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155865, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:16');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155866, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:16');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155867, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:16');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155868, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:16');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155869, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:16');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155870, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:17');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155871, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:17');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155872, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:17');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155873, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:18');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155874, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:18');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155875, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:18');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155876, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:18');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155877, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:18');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155878, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:18');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155879, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:18');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155880, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:19');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155881, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:19');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155882, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:19');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155883, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:19');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155884, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:19');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155885, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:19');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155886, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:19');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155887, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:19');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155888, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:19');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155889, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:20');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155890, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:20');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155891, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:20');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155892, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:20');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155893, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:20');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155894, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:20');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155895, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:20');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155896, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:20');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155897, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:20');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155898, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:21');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155899, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:21');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155900, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:21');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155901, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:21');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155902, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:21');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155903, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:21');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155904, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:21');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155905, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:21');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155906, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:21');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155907, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:21');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155908, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:22');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155909, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:45:22');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155910, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:50:37');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155911, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:50:38');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155912, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:50:38');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155913, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:50:38');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155914, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:34');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155915, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:34');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155916, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:35');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155917, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:35');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155918, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:36');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155919, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:37');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155920, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:37');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155921, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:38');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155922, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:39');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155923, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:40');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155924, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:40');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155925, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:41');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155926, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:41');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155927, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:41');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155928, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155929, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155930, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155931, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155932, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:44');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155933, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155934, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155935, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 10:51:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155936, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:34');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155937, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:35');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155938, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:35');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155939, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:36');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155940, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:37');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155941, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:37');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155942, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:38');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155943, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:39');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155944, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:40');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155945, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:40');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155946, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:41');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155947, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155948, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155949, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:44');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155950, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155951, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155952, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155953, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:46');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155954, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:46');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155955, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:46');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155956, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155957, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155958, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155959, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155960, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155961, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:49');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155962, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:49');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155963, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:50');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155964, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:50');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155965, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:51');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155966, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:51');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155967, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:51');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155968, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:51');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155969, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:51');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155970, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:51');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155971, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:52');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155972, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:52');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155973, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:52');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155974, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:52');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155975, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:52');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155976, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:53');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155977, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:53');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155978, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:53');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155979, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:54');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155980, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:54');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155981, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:54');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155982, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:54');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155983, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:54');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155984, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:54');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155985, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:55');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155986, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:55');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155987, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:55');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155988, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:55');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155989, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:55');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155990, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:56');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155991, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:56');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155992, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:56');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155993, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:56');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155994, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:56');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155995, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:56');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155996, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:57');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155997, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:57');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155998, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:57');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015155999, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:57');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156000, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:57');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156001, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:57');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156002, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:57');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156003, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:57');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156004, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:57');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156005, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:58');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156006, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:58');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156007, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:58');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156008, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:58');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156009, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:58');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156010, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:58');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156011, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:58');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156012, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156013, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156014, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156015, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156016, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156017, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156018, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156019, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156020, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156021, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156022, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156023, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156024, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156025, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156026, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156027, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156028, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:07:59');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156029, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:08:00');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156030, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:08:00');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156031, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:08:00');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156032, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:08:00');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156033, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:08:00');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156034, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:08:00');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156035, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:08:01');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156036, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:29');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156037, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:29');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156038, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:29');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156039, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:29');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156040, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:30');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156041, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:30');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156042, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:30');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156043, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:30');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156044, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:31');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156045, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:31');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156046, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:31');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156047, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:31');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156048, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:31');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156049, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:32');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156050, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:32');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156051, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:33');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156052, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:33');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156053, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:33');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156054, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:34');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156055, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:34');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156056, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:36');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156057, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:36');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156058, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:37');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156059, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:37');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156060, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:37');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156061, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:38');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156062, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:38');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156063, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:39');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156064, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:39');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156065, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:40');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156066, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:40');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156067, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:40');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156068, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:41');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156069, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:41');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156070, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:41');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156071, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:41');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156072, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:41');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156073, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156074, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156075, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156076, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156077, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156078, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156079, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156080, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156081, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:42');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156082, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156083, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156084, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156085, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156086, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156087, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156088, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156089, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:43');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156090, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:44');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156091, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:44');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156092, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:44');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156093, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156094, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156095, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156096, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156097, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156098, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156099, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156100, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156101, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156102, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156103, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156104, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156105, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:45');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156106, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:46');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156107, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:46');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156108, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:46');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156109, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:46');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156110, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:46');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156111, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156112, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156113, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156114, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156115, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156116, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156117, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156118, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156119, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156120, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:47');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156121, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156122, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156123, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156124, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156125, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156126, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156127, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156128, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156129, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156130, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156131, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156132, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156133, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156134, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');
INSERT INTO igsystem.post (id, title, content, view_count, like_count, author_id, created_at) VALUES (1802223347015156135, 'Study!!!!!!', 'Jun & Wonwoo is true couple', 0, 0, 1018, '2024-12-27 11:19:48');