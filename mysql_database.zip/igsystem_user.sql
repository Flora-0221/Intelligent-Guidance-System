create table user
(
    id          bigint unsigned auto_increment comment '主键'
        primary key,
    phone       varchar(11)                                                    not null comment '手机号码',
    password    varchar(128)                         default ''                null comment '密码，加密存储',
    nick_name   varchar(32)                          default ''                null comment '昵称，默认是用户id',
    icon        varchar(255)                         default ''                null comment '人物头像',
    create_time timestamp                            default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time timestamp                            default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    gender      enum ('male', 'female', 'other')     default 'other'           null comment '性别',
    occupation  enum ('teacher', 'student', 'other') default 'other'           null comment '职业',
    country     varchar(32)                          default ''                null comment '国家',
    address     varchar(255)                         default ''                null comment '地址',
    email       varchar(64)                          default ''                null comment '邮箱',
    birthdate   date                                                           null comment '出生日期',
    age         int unsigned                                                   null comment '年龄',
    comment     varchar(255)                         default ''                null comment '个性签名',
    constraint uniqe_key_phone
        unique (phone)
)
    collate = utf8mb4_general_ci;

INSERT INTO igsystem.user (id, phone, password, nick_name, icon, create_time, update_time, gender, occupation, country, address, email, birthdate, age, comment) VALUES (1013, '13829396233', '123123', 'User123', 'user_avatar.jpg', '2024-03-05 11:32:27', '2024-03-05 19:34:43', 'other', 'other', '', '', '', null, null, '');
INSERT INTO igsystem.user (id, phone, password, nick_name, icon, create_time, update_time, gender, occupation, country, address, email, birthdate, age, comment) VALUES (1017, '19860318728', '666666', 'Flora_woea8sytk5', '', '2024-03-05 21:07:48', '2024-03-05 21:07:48', 'male', 'teacher', 'China', '123 Street, City', 'user123@example.com', null, null, '');
INSERT INTO igsystem.user (id, phone, password, nick_name, icon, create_time, update_time, gender, occupation, country, address, email, birthdate, age, comment) VALUES (1018, '13502310866', '666666', 'Jack', 'api/user/download?name=f5045e18-98cc-4ca1-88dd-144a48a092f3.jpg', '2024-03-06 10:27:56', '2024-04-03 13:54:57', 'male', 'student', 'China', 'Beijing, China', 'user123@example.com', '1990-01-01', 34, 'Optional comment');
INSERT INTO igsystem.user (id, phone, password, nick_name, icon, create_time, update_time, gender, occupation, country, address, email, birthdate, age, comment) VALUES (1020, '13555555555', '666666', 'Flora_xj11bb43jv', '', '2024-03-08 09:52:11', '2024-03-08 09:52:11', 'male', 'teacher', '', '', 'user123@example.com', '1990-01-01', 12, '');
INSERT INTO igsystem.user (id, phone, password, nick_name, icon, create_time, update_time, gender, occupation, country, address, email, birthdate, age, comment) VALUES (1021, '13123123123', '123123', '123123', '', '2024-03-08 11:30:55', '2024-03-08 11:30:55', 'female', 'student', '', '', '123@qq.com', '2020-03-18', 4, '');
INSERT INTO igsystem.user (id, phone, password, nick_name, icon, create_time, update_time, gender, occupation, country, address, email, birthdate, age, comment) VALUES (1022, '13123123125', '123123', '1231235', '', '2024-03-08 11:32:19', '2024-03-08 11:32:19', 'female', 'student', '', '', '123@qq.com', '2020-03-18', 4, '');