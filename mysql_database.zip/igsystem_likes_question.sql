create table likes_question
(
    id          bigint unsigned auto_increment
        primary key,
    question_id bigint unsigned                     null,
    user_id     bigint unsigned                     null,
    created_at  timestamp default CURRENT_TIMESTAMP null,
    constraint likes_question_ibfk_1
        foreign key (question_id) references user_question (id),
    constraint likes_question_ibfk_2
        foreign key (user_id) references user (id)
);

create index question_id
    on likes_question (question_id);

create index user_id
    on likes_question (user_id);

