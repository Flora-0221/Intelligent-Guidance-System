create table favorite_questions
(
    favorite_id   int             not null,
    question_id   int             not null,
    question_type varchar(50)     not null,
    user_id       bigint unsigned not null,
    primary key (favorite_id, question_id, question_type, user_id),
    constraint favorite_questions_ibfk_1
        foreign key (favorite_id) references favorites (id),
    constraint favorite_questions_ibfk_2
        foreign key (question_id) references problems (id),
    constraint favorite_questions_ibfk_3
        foreign key (question_id) references s_a_question (id),
    constraint favorite_questions_ibfk_4
        foreign key (user_id) references user (id)
);

create index question_id
    on favorite_questions (question_id);

create index user_id
    on favorite_questions (user_id);

INSERT INTO igsystem.favorite_questions (favorite_id, question_id, question_type, user_id) VALUES (3, 1, 'closed choice', 1018);
INSERT INTO igsystem.favorite_questions (favorite_id, question_id, question_type, user_id) VALUES (3, 2, 'closed choice', 1018);
INSERT INTO igsystem.favorite_questions (favorite_id, question_id, question_type, user_id) VALUES (3, 3, 'closed choice', 1018);
INSERT INTO igsystem.favorite_questions (favorite_id, question_id, question_type, user_id) VALUES (3, 4, 'closed choice', 1018);
INSERT INTO igsystem.favorite_questions (favorite_id, question_id, question_type, user_id) VALUES (4, 6, 'closed choice', 1018);
INSERT INTO igsystem.favorite_questions (favorite_id, question_id, question_type, user_id) VALUES (4, 7, 'closed choice', 1018);